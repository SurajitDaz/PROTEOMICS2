from pathlib import Path
import hashlib, shutil, zipfile

root = Path(__file__).resolve().parent
data = root / "data"
target = data / "CPTAC3_Lung_Adeno_Carcinoma_Proteome.tmt10.tsv"
parts = [data / (target.name + f".chunk{i}") for i in range(1, 4)]
expected = "345122222689360c9430b3795336e34f612531fc38bb55c87c001aaff8e0778a"
def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

if not target.exists() or digest(target) != expected:
    for part in parts:
        if not part.is_file():
            raise FileNotFoundError(f"Extract all three ZIPs into the same folder. Missing {part.name}")
    temporary = target.with_suffix(".assembling")
    with temporary.open("wb") as output:
        for part in parts:
            with part.open("rb") as stream:
                shutil.copyfileobj(stream, output)
    if digest(temporary) != expected:
        raise ValueError("Reassembled input failed SHA-256 verification.")
    temporary.replace(target)
print(f"Verified {target.name}")

if "--colab" in __import__("sys").argv:
    names = (target.name, "CPTAC3_Lung_Adeno_Carcinoma_Proteome.summary.tsv",
             "CPTAC3_Lung_Adeno_Carcinoma_Proteome.sample.txt",
             "PDC_biospecimen_manifest_09132026_184313.csv")
    archive = root / "IWMMA_LUAD_Colab_Inputs.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as output:
        for name in names:
            output.write(data / name, f"data/{name}")
    print(f"Upload {archive.name} to Colab when prompted.")
