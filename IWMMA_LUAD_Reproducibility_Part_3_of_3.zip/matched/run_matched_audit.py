# Generated from the verified notebook with local paths and CLI arguments.
from pathlib import Path
from zipfile import ZipFile
import shutil, hashlib, json
from importlib.metadata import version
from IPython.display import display
from scipy.stats import false_discovery_control
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import matthews_corrcoef

import argparse
parser = argparse.ArgumentParser(description="Run the matched CPTAC-LUAD audit.")
parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[1] / "data")
parser.add_argument("--output-dir", type=Path, default=Path.cwd() / "luad_rerun")
args = parser.parse_args()
BASE_DIR = str(args.output_dir.resolve())
DATA_DIR = str(args.data_dir.resolve())
OUT_DIR = OUTPUT_DIR = BASE_DIR + '/FOL_ILP_Benchmark/OUTPUT'
INTERMEDIATE_DIR = BASE_DIR + '/FOL_ILP_Benchmark/Intermediate'
for folder in (DATA_DIR, OUT_DIR, INTERMEDIATE_DIR):
    Path(folder).mkdir(parents=True, exist_ok=True)
names = (
    'CPTAC3_Lung_Adeno_Carcinoma_Proteome.tmt10.tsv',
    'CPTAC3_Lung_Adeno_Carcinoma_Proteome.summary.tsv',
    'CPTAC3_Lung_Adeno_Carcinoma_Proteome.sample.txt',
    'PDC_biospecimen_manifest_09132026_184313.csv',
)
TMT_FILE, SUMMARY_FILE, SAMPLE_FILE, BIOSPEC_FILE = [str(Path(DATA_DIR) / n) for n in names]
if not all((Path(DATA_DIR) / n).is_file() for n in names):
    raise FileNotFoundError(f"Expected the four source files under {DATA_DIR}.")
manifest = {
    'versions': {p: version(p) for p in ['numpy','pandas','scipy','scikit-learn','matplotlib']},
    'inputs_sha256': {n: hashlib.file_digest((Path(DATA_DIR)/n).open('rb'), 'sha256').hexdigest() for n in names},
}
assert manifest['versions']['scikit-learn'] == '1.8.0'
(Path(OUT_DIR)/'matched_run_manifest.json').write_text(json.dumps(manifest, indent=2))

def multipletests(values, method):
    return None, false_discovery_control(values, method='bh')


import os, re, zipfile, time, math, warnings, json
from collections import Counter, defaultdict
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import ttest_1samp

from sklearn.model_selection import StratifiedGroupKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (roc_auc_score, average_precision_score, accuracy_score,
    balanced_accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, roc_curve, precision_recall_curve)
warnings.filterwarnings('ignore')

RANDOM_STATE = 42
MAX_MISSING_FRACTION = 0.20
MIN_PAIRED_CASES_FOR_TEST = 10
OUTER_SPLITS = 5
INNER_SPLITS = 4
TOP_N_TRAINING_FEATURES = 100
C_GRID = [0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0]

ILP_OUTER_SPLITS = 5
ILP_TOP_PROTEINS = 14
ILP_MAX_RULE_LEN = 3
ILP_BEAM_WIDTH = 30
ILP_MAX_RULES = 4
ILP_MIN_POS_COVERAGE = 4
ILP_MIN_PRECISION = 0.75
ILP_SHAP_QUANTILE = 0.60
ILP_DIFF_FDR = 0.05

# Capture versions from the environment actually used for this run.
from importlib.metadata import version, PackageNotFoundError
PACKAGE_VERSIONS = {}
for package in ["numpy", "pandas", "scipy", "scikit-learn", "matplotlib"]:
    try:
        PACKAGE_VERSIONS[package] = version(package)
    except PackageNotFoundError:
        PACKAGE_VERSIONS[package] = "not installed"
print("Environment versions:", PACKAGE_VERSIONS)
print('Analysis settings loaded. Outputs will be written to:', OUT_DIR)

# Strict path audit: inputs are read from DATA_DIR; outputs are written under BASE_DIR/FOL_ILP
assert os.path.isdir(DATA_DIR)
assert OUT_DIR == os.path.join(BASE_DIR, "FOL_ILP_Benchmark", "OUTPUT")
assert INTERMEDIATE_DIR == os.path.join(BASE_DIR, "FOL_ILP_Benchmark", "Intermediate")
assert all(os.path.isfile(p) for p in [TMT_FILE, SUMMARY_FILE, SAMPLE_FILE, BIOSPEC_FILE])
print("Path audit passed.")

TMT_FILE = os.path.join(DATA_DIR, 'CPTAC3_Lung_Adeno_Carcinoma_Proteome.tmt10.tsv')
SUMMARY_FILE = os.path.join(DATA_DIR, 'CPTAC3_Lung_Adeno_Carcinoma_Proteome.summary.tsv')
SAMPLE_FILE = os.path.join(DATA_DIR, 'CPTAC3_Lung_Adeno_Carcinoma_Proteome.sample.txt')
BIOSPEC_FILE = os.path.join(DATA_DIR, 'PDC_biospecimen_manifest_09132026_184313.csv')
for f in [TMT_FILE, SUMMARY_FILE, SAMPLE_FILE, BIOSPEC_FILE]:
    assert os.path.exists(f), f'Missing file: {f}'

tmt = pd.read_csv(TMT_FILE, sep='\t', low_memory=False)
summary = pd.read_csv(SUMMARY_FILE, sep='\t', low_memory=False)
sample_map = pd.read_csv(SAMPLE_FILE, sep='\t')
biospec = pd.read_csv(BIOSPEC_FILE, low_memory=False)

bio = biospec[biospec['Sample Type'].isin(['Primary Tumor', 'Solid Tissue Normal'])].copy()
bio['Class'] = bio['Sample Type'].map({'Primary Tumor':'Tumor', 'Solid Tissue Normal':'Normal'})
bio['y'] = bio['Class'].map({'Normal':0, 'Tumor':1}).astype(int)
pattern = re.compile(r'^(CPT\d+)(?:\.\d+)? Log Ratio$')
sample_columns = []
for col in tmt.columns:
    m = pattern.match(str(col))
    if m: sample_columns.append((col, m.group(1)))
assert sample_columns, 'No CPT... Log Ratio columns found in TMT table.'
assert 'Gene' in tmt.columns, 'Gene column not found.'
quant = tmt[['Gene'] + [c for c,_ in sample_columns]].copy()
quant = quant[quant['Gene'].notna()].copy()
quant['Gene'] = quant['Gene'].astype(str).str.strip()
quant = quant[quant['Gene'] != '']
for col,_ in sample_columns: quant[col] = pd.to_numeric(quant[col], errors='coerce')
cols = [c for c,_ in sample_columns]
quant = quant.groupby('Gene', as_index=False)[cols].median(numeric_only=True)
tmp = quant.set_index('Gene').T
col_to_aliquot = {c:a for c,a in sample_columns}
tmp['Aliquot Submitter ID'] = [col_to_aliquot[i] for i in tmp.index]
protein_cols = [c for c in tmp.columns if c != 'Aliquot Submitter ID']
X_all = tmp.groupby('Aliquot Submitter ID')[protein_cols].mean()
metadata = bio[['Aliquot Submitter ID','Case Submitter ID','Sample Type','Tissue Type','Class','y']].drop_duplicates(subset=['Aliquot Submitter ID'])
metadata = metadata[metadata['Aliquot Submitter ID'].isin(X_all.index)].copy().set_index('Aliquot Submitter ID')
X_all = X_all.loc[metadata.index]

print('Matrix:', X_all.shape)
print('Samples by class:\n', metadata['Class'].value_counts())
print('Unique patients:', metadata['Case Submitter ID'].nunique())
print('Patients with both tumour and normal:', metadata.groupby('Case Submitter ID')['Class'].nunique().eq(2).sum())

# Guard against accidentally analysing a partial or mismatched cohort.
assert len(metadata) == 213, f"Expected 213 tissue samples, found {len(metadata)}"
assert int((metadata['Class'] == 'Tumor').sum()) == 111
assert int((metadata['Class'] == 'Normal').sum()) == 102
assert metadata['Case Submitter ID'].nunique() == 111
assert metadata.groupby('Case Submitter ID')['Class'].nunique().eq(2).sum() == 102
print("Cohort identity checks passed: 213 samples; 111 tumours; 102 normals; 102 matched pairs.")
def train_only_filter(X_train, max_missing=MAX_MISSING_FRACTION):
    keep = X_train.columns[X_train.isna().mean(axis=0) <= max_missing]
    Xf = X_train.loc[:, keep]
    variances = Xf.var(axis=0, skipna=True)
    return variances[variances > 1e-12].index.tolist()

def paired_diff_stats(X_df, meta_df, min_pairs=MIN_PAIRED_CASES_FOR_TEST):
    proteins = list(X_df.columns)
    work = X_df.copy()
    work['_case'] = meta_df.loc[X_df.index, 'Case Submitter ID'].astype(str).values
    work['_class'] = meta_df.loc[X_df.index, 'Class'].values
    tumor = work[work['_class']=='Tumor'].groupby('_case')[proteins].mean()
    normal = work[work['_class']=='Normal'].groupby('_case')[proteins].mean()
    common = tumor.index.intersection(normal.index)
    if len(common) == 0:
        raise ValueError('No matched tumour-normal patients in this training partition.')
    T, N = tumor.loc[common].to_numpy(float), normal.loc[common].to_numpy(float)
    D = T - N
    rows=[]
    for j,p in enumerate(proteins):
        d = D[:,j]
        d = d[np.isfinite(d)]
        n = len(d)
        if n >= min_pairs:
            if np.nanstd(d, ddof=1) == 0:
                stat = np.inf if np.nanmean(d) != 0 else 0.0
                pv = 0.0 if np.nanmean(d) != 0 else 1.0
            else:
                tt = ttest_1samp(d, popmean=0.0, nan_policy='omit')
                stat, pv = float(tt.statistic), float(tt.pvalue)
            mdiff = float(np.mean(d))
            rows.append((p,n,mdiff,float(np.mean(T[np.isfinite(D[:,j]),j])),
                         float(np.mean(N[np.isfinite(D[:,j]),j])),stat,pv))
    out = pd.DataFrame(rows, columns=['Protein','N_pairs','Mean_log_ratio_difference','Tumor_mean_complete_pairs','Normal_mean_complete_pairs','T_statistic','P_value'])
    if out.empty: raise ValueError('No proteins passed minimum complete-pair count.')
    out['FDR'] = multipletests(out['P_value'].fillna(1.0), method='fdr_bh')[1]
    out['Direction'] = np.where(out['Mean_log_ratio_difference']>0,'Up_in_Tumor',np.where(out['Mean_log_ratio_difference']<0,'Down_in_Tumor','No_change'))
    return out.sort_values(['FDR','P_value'], na_position='last').reset_index(drop=True)

def select_features_from_training(X_train_raw, meta_train, top_n=TOP_N_TRAINING_FEATURES):
    qc = train_only_filter(X_train_raw)
    if len(qc) < 5: raise RuntimeError('Fewer than five proteins pass training-only QC.')
    Xq = X_train_raw[qc]
    diff = paired_diff_stats(Xq, meta_train)
    selected = diff.dropna(subset=['P_value']).head(top_n)['Protein'].tolist()
    if len(selected) < 5: raise RuntimeError(f'Only {len(selected)} proteins selected.')
    return qc, diff, selected

def fit_transform_train_test(Xtr, Xte):
    imp = SimpleImputer(strategy='median')
    sc = StandardScaler()
    A = sc.fit_transform(imp.fit_transform(Xtr))
    B = sc.transform(imp.transform(Xte))
    return A,B,imp,sc

print('Helper functions ready.')
def nested_choose_C(X_train_raw, meta_train, C_grid=C_GRID, n_splits=INNER_SPLITS, seed=RANDOM_STATE):
    """Each inner split independently fits QC, paired feature ranking, imputation and scaling."""
    ytr = meta_train['y'].to_numpy(dtype=int)
    gtr = meta_train['Case Submitter ID'].astype(str).to_numpy()
    inner = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    cached=[]
    for it, iv in inner.split(X_train_raw, ytr, gtr):
        ids_tr = X_train_raw.index[it]; ids_va = X_train_raw.index[iv]
        mtr = meta_train.loc[ids_tr]
        qc_i, diff_i, feat_i = select_features_from_training(X_train_raw.loc[ids_tr], mtr)
        Xtr_i = X_train_raw.loc[ids_tr, feat_i]
        Xva_i = X_train_raw.loc[ids_va, feat_i]
        A,B,_,_ = fit_transform_train_test(Xtr_i, Xva_i)
        cached.append((A,B,ytr[it],ytr[iv]))
    scores={}
    for C in C_grid:
        vals=[]
        for A,B,yi,yv in cached:
            model=LogisticRegression(penalty='l1',solver='liblinear',C=C,class_weight='balanced',max_iter=5000,random_state=RANDOM_STATE)
            model.fit(A,yi)
            pr=model.predict_proba(B)[:,1]
            if len(np.unique(yv))==2: vals.append(roc_auc_score(yv,pr))
        scores[C]=float(np.mean(vals)) if vals else -np.inf
    best=max(scores,key=scores.get)
    return best,scores

def pooled_metrics(y_true, prob, pred):
    tn,fp,fn,tp=confusion_matrix(y_true,pred,labels=[0,1]).ravel()
    return pd.DataFrame({'Metric':['ROC-AUC','PR-AUC','Accuracy','Balanced Accuracy','Precision','Sensitivity','Specificity','F1'],
      'Value':[roc_auc_score(y_true,prob),average_precision_score(y_true,prob),accuracy_score(y_true,pred),balanced_accuracy_score(y_true,pred),precision_score(y_true,pred,zero_division=0),recall_score(y_true,pred,zero_division=0),tn/(tn+fp) if tn+fp else np.nan,f1_score(y_true,pred,zero_division=0)]})

y = metadata['y'].to_numpy(dtype=int)
groups = metadata['Case Submitter ID'].astype(str).to_numpy()


def paired_diff_stats(X_df, meta_df, min_pairs=MIN_PAIRED_CASES_FOR_TEST):
    g=meta_df['Case Submitter ID']; q=meta_df.y
    t=X_df[q.eq(1)].groupby(g[q.eq(1)]).mean()
    n=X_df[q.eq(0)].groupby(g[q.eq(0)]).mean()
    cases=t.index.intersection(n.index)
    dd=t.loc[cases].to_numpy()-n.loc[cases].to_numpy()
    count=np.isfinite(dd).sum(0); ok=count>=min_pairs
    dd=dd[:,ok]; dd[~np.isfinite(dd)]=np.nan
    md=np.nanmean(dd,axis=0)
    from scipy.special import stdtr
    sd=np.nanstd(dd,axis=0,ddof=1)
    st=md*np.sqrt(count[ok])/sd
    p=2*stdtr(count[ok]-1,-abs(st))
    zeros=sd==0
    p=np.where(zeros,np.where(md==0,1.,0.),p)
    out=pd.DataFrame(dict(Protein=X_df.columns[ok],N_pairs=count[ok],Mean_log_ratio_difference=md,P_value=p,FDR=false_discovery_control(np.nan_to_num(p,nan=1.)),Direction=np.where(md>0,'Up_in_Tumor',np.where(md<0,'Down_in_Tumor','No_change'))))
    return out.sort_values(['FDR','P_value'],na_position='last').reset_index(drop=True)
qc=train_only_filter(X_all)
d=paired_diff_stats(X_all[qc],metadata)
sig=d[(d.FDR<.05)&(d.Mean_log_ratio_difference.abs()>=1)]
print('differential',len(qc),len(d),d.N_pairs.agg(['min','median','max']).to_dict(),sig.Direction.value_counts().to_dict(),flush=True)


def linear_shap_independent(model, X_background, X_explain):
    # Exact interventional/independent-background SHAP for a linear model.
    return (np.asarray(X_explain)-np.asarray(X_background).mean(axis=0))*model.coef_[0]

def safe_atom(s):
    s=re.sub(r'[^A-Za-z0-9_]', '_', str(s).strip().lower())
    if not s: s='unknown'
    if s[0].isdigit(): s='p_'+s
    return s

def make_specific_literal(protein,state):
    return {'name':f'{state}_{safe_atom(protein)}','prolog':f'{state}(X,{safe_atom(protein)})','kind':'specific','protein':protein,'state':state}
def make_relational_literal(state,direction,evidence):
    return {'name':f'exists_{state}_{direction}_{evidence}','prolog':f'{state}(X,P), {direction}(P), {evidence}(P)','kind':'relational','state':state,'direction':direction,'evidence':evidence}
def eval_literal(literal,kb):
    if literal['kind']=='specific':
        p=literal['protein']
        if p not in kb['states'].columns: return np.zeros(len(kb['states']),dtype=bool)
        arr=kb['states'][p].to_numpy()
        return arr==1 if literal['state']=='high' else arr==0
    proteins=(kb['protein_sets'].get(literal['direction'],set()) & kb['protein_sets'].get(literal['evidence'],set()) & set(kb['states'].columns))
    if not proteins: return np.zeros(len(kb['states']),dtype=bool)
    M=kb['states'][sorted(proteins)].to_numpy()
    return (M==1).any(axis=1) if literal['state']=='high' else (M==0).any(axis=1)
def eval_clause(clause,kb):
    mask=np.ones(len(kb['states']),dtype=bool)
    for lit in clause: mask &= eval_literal(lit,kb)
    return mask
def clause_to_prolog(clause):
    terms = [re.sub(r'\bP\b', ('P' if sum(t['kind']=='relational' for t in clause)==1 else f'P{i}'), lit['prolog'])
             if lit['kind'] == 'relational' else lit['prolog']
             for i, lit in enumerate(clause, 1)]
    return 'tumor(X) :- ' + ', '.join(terms) + '.'
def rule_set_predict(rule_set,kb):
    if not rule_set: return np.zeros(len(kb['states']),dtype=int)
    fired=np.zeros(len(kb['states']),dtype=bool)
    for clause in rule_set: fired |= eval_clause(clause,kb)
    return fired.astype(int)
def candidate_literal_pool(kb):
    literals=[]
    for p in kb['candidate_proteins']:
        literals += [make_specific_literal(p,'high'),make_specific_literal(p,'low')]
    specs=[('low','down_in_tumor','high_shap'),('high','up_in_tumor','high_shap'),('low','down_in_tumor','differential'),('high','up_in_tumor','differential'),('low','down_in_tumor','stable'),('high','up_in_tumor','stable'),('high','down_in_tumor','high_shap'),('low','up_in_tumor','high_shap')]
    literals += [make_relational_literal(*s) for s in specs if kb['protein_sets'].get(s[1]) and kb['protein_sets'].get(s[2])]
    return literals
def clause_metrics(clause,kb,positive_mask=None):
    yt=kb['y'].astype(int); positive_mask=(yt==1) if positive_mask is None else positive_mask
    fired=eval_clause(clause,kb); tp=int(np.sum(fired&positive_mask)); fp=int(np.sum(fired&(yt==0))); fn=int(np.sum((~fired)&positive_mask))
    prec=tp/(tp+fp) if tp+fp else 0.; rec=tp/(tp+fn) if tp+fn else 0.; f1=2*prec*rec/(prec+rec) if prec+rec else 0.
    return {'tp':tp,'fp':fp,'fn':fn,'precision':prec,'recall':rec,'f1':f1,'score':f1-.015*max(0,len(clause)-1)}
def canonical_clause_key(clause): return tuple(sorted(l['name'] for l in clause))
def beam_search_best_clause(kb,positive_mask):
    pool=candidate_literal_pool(kb); beam=[tuple()]; seen=set(); all_candidates=[]
    for depth in range(1,ILP_MAX_RULE_LEN+1):
        expanded=[]
        for clause in beam:
            used={x['name'] for x in clause}
            for lit in pool:
                if lit['name'] in used: continue
                new=tuple(list(clause)+[lit]); key=canonical_clause_key(new)
                if key in seen: continue
                seen.add(key); m=clause_metrics(new,kb,positive_mask)
                if m['tp']<ILP_MIN_POS_COVERAGE: continue
                rec={'clause':new,**m}; expanded.append(rec); all_candidates.append(rec)
        if not expanded: break
        expanded.sort(key=lambda z:(z['score'],z['precision'],z['tp'],-len(z['clause'])),reverse=True)
        beam=[z['clause'] for z in expanded[:ILP_BEAM_WIDTH]]
    acceptable=[z for z in all_candidates if z['precision']>=ILP_MIN_PRECISION and z['tp']>=ILP_MIN_POS_COVERAGE]
    if not acceptable: return None
    acceptable.sort(key=lambda z:(z['score'],z['precision'],z['tp'],-len(z['clause'])),reverse=True)
    return acceptable[0]
def learn_rule_set(kb):
    ytrue=kb['y'].astype(int); uncovered=ytrue==1; learned=[]; rows=[]
    for ridx in range(1,ILP_MAX_RULES+1):
        if uncovered.sum()<ILP_MIN_POS_COVERAGE: break
        best=beam_search_best_clause(kb,uncovered)
        if best is None: break
        clause=list(best['clause']); fired=eval_clause(clause,kb); newly=fired&uncovered
        if newly.sum()<ILP_MIN_POS_COVERAGE: break
        learned.append(clause); rows.append({'Rule':ridx,'Horn_clause':clause_to_prolog(clause),'TP_on_uncovered':best['tp'],'FP':best['fp'],'Precision':best['precision'],'Recall_on_uncovered':best['recall'],'F1_on_uncovered':best['f1'],'Length':len(clause)})
        uncovered &= ~fired
    return learned,pd.DataFrame(rows)

def build_fold_kb(Xtr_raw,Xte_raw,mtr,mte,top_n_proteins=ILP_TOP_PROTEINS, use_shap=True, coefficient=False):
    qc=train_only_filter(Xtr_raw)
    Xtr=Xtr_raw[qc].copy(); Xte=Xte_raw[qc].copy()
    diff=paired_diff_stats(Xtr,mtr)
    preselected=diff.dropna(subset=['P_value']).head(TOP_N_TRAINING_FEATURES).Protein.tolist()
    if len(preselected)<5: raise RuntimeError('Insufficient fold-level features for FOL/ILP.')
    # C tuning has a fresh paired feature-selection operation inside every inner training fold.
    best_C,inner_scores=nested_choose_C(Xtr_raw,mtr,seed=RANDOM_STATE+17)
    A,_,imp,sc=fit_transform_train_test(Xtr[preselected],Xtr[preselected])
    clf=LogisticRegression(penalty='l1',solver='liblinear',C=best_C,class_weight='balanced',max_iter=5000,random_state=RANDOM_STATE)
    clf.fit(A,mtr.y.to_numpy(dtype=int))
    sv=linear_shap_independent(clf,A,A)
    shap_df=pd.DataFrame({'Protein':preselected,'Mean_abs_SHAP':np.mean(np.abs(sv),axis=0),'Coefficient':clf.coef_[0]})
    if coefficient:
        shap_df['Mean_abs_SHAP'] = shap_df.Coefficient.abs()
    cut=float(np.quantile(shap_df.Mean_abs_SHAP.to_numpy(),ILP_SHAP_QUANTILE))
    shap_df['High_SHAP']=shap_df.Mean_abs_SHAP>=cut
    evidence=diff[['Protein','Mean_log_ratio_difference','FDR','Direction']].merge(shap_df,on='Protein',how='left')
    evidence['Mean_abs_SHAP']=evidence.Mean_abs_SHAP.fillna(0.)
    evidence['High_SHAP']=evidence.High_SHAP.fillna(False).astype(bool)
    evidence['Coefficient']=evidence.Coefficient.fillna(0.)
    evidence['Differential']=evidence.FDR.fillna(1.)<ILP_DIFF_FDR
    evidence['Stable']=evidence.Coefficient.abs()>0
    evidence['FDR_rank_score']=-np.log10(evidence.FDR.fillna(1.).clip(lower=1e-300))
    candidates=(evidence[evidence.Protein.isin(preselected)].sort_values(['High_SHAP','Mean_abs_SHAP','FDR_rank_score'],ascending=[False,False,False]).head(top_n_proteins).Protein.tolist())
    if not use_shap:
        candidates = preselected[:top_n_proteins]
    med=Xtr[candidates].median(axis=0,skipna=True)
    Xtr_d=Xtr[candidates].fillna(med); Xte_d=Xte[candidates].fillna(med)
    thresholds=Xtr_d.median(axis=0)
    train_states=Xtr_d.gt(thresholds,axis=1).astype(int); test_states=Xte_d.gt(thresholds,axis=1).astype(int)
    ev=evidence.set_index('Protein')
    pset=lambda mask:set(ev.index[mask].tolist())
    protein_sets={'up_in_tumor':pset(ev.Mean_log_ratio_difference>0),'down_in_tumor':pset(ev.Mean_log_ratio_difference<0),'differential':pset(ev.Differential==True),'high_shap':pset(ev.High_SHAP==True),'stable':pset(ev.Stable==True)}
    if not use_shap:
        protein_sets['high_shap'] = set()
    kbtr={'states':train_states,'protein_sets':protein_sets,'y':mtr.loc[train_states.index,'y'].to_numpy(dtype=int),'thresholds':thresholds.to_dict(),'candidate_proteins':candidates}
    kbte={'states':test_states,'protein_sets':protein_sets,'y':mte.loc[test_states.index,'y'].to_numpy(dtype=int),'thresholds':thresholds.to_dict(),'candidate_proteins':candidates}
    return kbtr,kbte,evidence,{'best_C':best_C,'inner_scores':inner_scores,'candidate_proteins':candidates,'n_qc':len(qc),'n_preselected':len(preselected), 'model':clf, 'features':preselected, 'imputer':imp, 'scaler':sc}

print('FOL/ILP learner ready.')

original_eval_literal=eval_literal
def eval_literal(term,kb):
    cache=kb.setdefault('_term_cache',{})
    if term['name'] not in cache:
        cache[term['name']]=original_eval_literal(term,kb)
    return cache[term['name']]


EXTRA_GROUPED_SEEDS = []
RUN_PAIRED_ONLY = True
BOOTSTRAP_REPLICATES = 1000
gate_rows, tuning_rows = [], []
pred_rows, clause_rows, witness_rows, fold_rows = [], [], [], []

def witnesses(term, kb, sample):
    wanted = 1 if term['state'] == 'high' else 0
    states = kb['states'].loc[sample]
    proteins = ({term['protein']} if term['kind'] == 'specific' else
                kb['protein_sets'][term['direction']] & kb['protein_sets'][term['evidence']])
    return sorted(p for p in proteins if p in states.index and states[p] == wanted)

def run_matched(cohort, meta, seed):
    X = X_all.loc[meta.index]
    group = meta['Case Submitter ID']
    cv = StratifiedGroupKFold(n_splits=ILP_OUTER_SPLITS, shuffle=True, random_state=seed)
    for fold, (tr, te) in enumerate(cv.split(X, meta.y, group), 1):
        print(cohort, seed, fold, flush=True)
        mt, me = meta.iloc[tr], meta.iloc[te]
        assert not (set(group.iloc[tr]) & set(group.iloc[te]))
        xt, xe = X.iloc[tr], X.iloc[te]
        train, test, evidence, fit = build_fold_kb(xt, xe, mt, me)
        no_shap_tr, no_shap_te, _, _ = build_fold_kb(xt, xe, mt, me, use_shap=False)
        # Remove all relational terms, which each require direction evidence.
        def without_direction(kb):
            return {**kb, '_term_cache': {}, 'protein_sets': {k: v for k, v in kb['protein_sets'].items()
                                            if k not in ('up_in_tumor', 'down_in_tumor', 'differential')}}
        coef_tr, coef_te, coef_evidence, _ = build_fold_kb(xt, xe, mt, me, coefficient=True)
        shap_candidates = set(train['candidate_proteins'])
        coef_candidates = set(coef_tr['candidate_proteins'])
        scores = evidence.set_index('Protein').loc[fit['features'], 'Mean_abs_SHAP']
        gate_rows.append(dict(cohort=cohort, seed=seed, fold=fold,
            cutoff=float(scores.quantile(ILP_SHAP_QUANTILE)),
            passing=int(scores.ge(scores.quantile(ILP_SHAP_QUANTILE)).sum()),
            overlap=len(shap_candidates & coef_candidates),
            same_set=shap_candidates == coef_candidates))
        config = {'cohort':cohort, 'seed':seed, 'fold':fold}
        for C, auc in fit['inner_scores'].items():
            tuning_rows.append({**config, 'C': C, 'mean_inner_roc_auc': auc,
                                'selected': C == fit['best_C']})
        cols = fit['features']
        a, b = (fit['scaler'].transform(fit['imputer'].transform(z[cols])) for z in (xt, xe))
        prob = fit['model'].predict_proba(b)[:,1]
        lasso = (prob >= .5).astype(int)
        outputs = {'LASSO': (lasso, prob)}
        for name, model in {
            'Shallow tree':DecisionTreeClassifier(max_depth=3, min_samples_leaf=4, class_weight='balanced', random_state=42),
            'Random forest':RandomForestClassifier(n_estimators=300, class_weight='balanced', random_state=42, n_jobs=2),
        }.items():
            model.fit(a, mt.y)
            p = model.predict_proba(b)[:,1]
            outputs[name] = ((p >= .5).astype(int), p)
        arms = {
            'Full FOL/ILP':(train,test), 'Coefficient':(coef_tr,coef_te),
            'No SHAP':(no_shap_tr,no_shap_te),
            'No differential predicates':(without_direction(train),without_direction(test)),
            'Single threshold':(train,test),
        }
        for name,(train_kb,test_kb) in arms.items():
            if name == 'Single threshold':
                singles = [[term] for term in candidate_literal_pool(train_kb) if term['kind']=='specific']
                eligible = [(clause_metrics(c,train_kb),c) for c in singles]
                eligible = [(m,c) for m,c in eligible if m['tp']>=ILP_MIN_POS_COVERAGE and m['precision']>=ILP_MIN_PRECISION]
                rules = [max(eligible,key=lambda item:item[0]['score'])[1]] if eligible else []
            else:
                rules,_ = learn_rule_set(train_kb)
            pred = rule_set_predict(rules,test_kb)
            outputs[name] = (pred, np.full(len(me), np.nan))
            fold_rows.append({**config,'arm':name,'rules':len(rules),
                              'search_terms':sum(map(len,rules)),
                              'lasso_agreement':float(np.mean(pred==lasso))})
            for rid, clause in enumerate(rules,1):
                signature = ' & '.join(canonical_clause_key(clause))
                pattern = ' & '.join(sorted(t['name'] if t['kind']=='relational' else
                                            'specific_'+t['state'] for t in clause))
                clause_rows.append({**config,'arm':name,'rule_id':rid,'signature':signature,
                                    'pattern':pattern,'rule':clause_to_prolog(clause)})
                if name != 'Full FOL/ILP':
                    continue
                for j in np.flatnonzero(eval_clause(clause,test_kb)):
                    sample = me.index[j]
                    for term_index, term in enumerate(clause,1):
                        for protein in witnesses(term,test_kb,sample):
                            raw = xe.loc[sample,protein]
                            witness_rows.append({**config,'sample':sample,'patient':group.loc[sample],
                                'truth':int(me.y.iloc[j]),'rule_id':rid,'term':term_index,
                                'protein':protein,'state':term['state'],'raw_abundance':raw,
                                'imputed':bool(pd.isna(raw)),
                                'threshold':test_kb['thresholds'][protein]})
        for name,(pred,score) in outputs.items():
            for j,sample in enumerate(me.index):
                pred_rows.append({**config,'arm':name,'sample':sample,'patient':group.loc[sample],
                                  'truth':int(me.y.iloc[j]),'pred':int(pred[j]),'score':score[j]})

primary_seed = RANDOM_STATE + 17
for seed in dict.fromkeys([primary_seed] + EXTRA_GROUPED_SEEDS):
    run_matched('all patients',metadata,seed)
if RUN_PAIRED_ONLY:
    grouped = metadata.groupby('Case Submitter ID').y
    paired = grouped.nunique().loc[lambda x:x==2].index
    run_matched('paired only',metadata[metadata['Case Submitter ID'].isin(paired)],primary_seed)

def save_benchmark(name, data):
    pd.DataFrame(data).to_csv(os.path.join(OUTPUT_DIR,name+'.csv'),index=False)

predictions = pd.DataFrame(pred_rows)
keys = ['cohort','seed','arm']
assert not predictions.duplicated(keys+['sample']).any()
summary = []
for key, g in predictions.groupby(keys):
    y0,p = g.truth,g.pred
    tn,fp,fn,tp = confusion_matrix(y0,p,labels=[0,1]).ravel()
    summary.append(dict(zip(keys,key), accuracy=accuracy_score(y0,p),
        balanced_accuracy=balanced_accuracy_score(y0,p), sensitivity=recall_score(y0,p),
        specificity=tn/(tn+fp), precision=precision_score(y0,p,zero_division=0),
        f1=f1_score(y0,p,zero_division=0), mcc=matthews_corrcoef(y0,p),
        tn=tn,fp=fp,fn=fn,tp=tp,
        roc_auc=roc_auc_score(y0,g.score) if g.score.notna().all() else np.nan,
        average_precision=average_precision_score(y0,g.score) if g.score.notna().all() else np.nan))
save_benchmark('matched_oof_predictions',predictions)
save_benchmark('matched_metrics',summary)
save_benchmark('matched_rule_complexity',fold_rows)
save_benchmark('matched_clauses',clause_rows)
save_benchmark('heldout_rule_witnesses',witness_rows)
clauses = pd.DataFrame(clause_rows)
if not clauses.empty:
    for level in ('signature','pattern'):
        group_keys=['cohort','arm',level]
        freq=(clauses.drop_duplicates(group_keys+['seed','fold'])
              .groupby(group_keys).size().rename('folds_present').reset_index())
        totals=predictions[['cohort','seed','fold']].drop_duplicates().groupby('cohort').size()
        freq['folds_evaluated']=freq.cohort.map(totals)
        freq['frequency']=freq.folds_present/freq.folds_evaluated
        save_benchmark('rule_recurrence_'+level,freq)

rng=np.random.default_rng(42)
intervals=[]
for cohort,g in predictions[predictions.seed==primary_seed].groupby('cohort'):
    wide=g.pivot(index=['sample','patient','truth'],columns='arm',values='pred').reset_index()
    cluster=list(wide.groupby('patient').indices.values())
    draws=[np.concatenate([cluster[i] for i in rng.integers(len(cluster),size=len(cluster))])
           for _ in range(BOOTSTRAP_REPLICATES)]
    y0=wide.truth.to_numpy()
    ref=wide['Full FOL/ILP'].to_numpy()
    for arm in sorted(set(g.arm)-{'Full FOL/ILP'}):
        alt=wide[arm].to_numpy()
        metric=lambda i: f1_score(y0[i],ref[i],zero_division=0)-f1_score(y0[i],alt[i],zero_division=0)
        lo,hi=np.quantile([metric(i) for i in draws],[.025,.975])
        intervals.append({'cohort':cohort,'comparator':arm,'delta_f1':metric(np.arange(len(wide))),
                          'lower_95':lo,'upper_95':hi})
save_benchmark('paired_patient_bootstrap_delta_f1',intervals)
display(pd.DataFrame(summary))



channel_columns = ['126','127N','127C','128N','128C','129N','129C','130N','130C','131']
channels = (sample_map.melt(value_vars=channel_columns, var_name='channel', value_name='sample')
            .dropna(subset=['sample']).drop_duplicates())
channel_predictions = []
for (cohort, seed), oo in predictions[predictions.arm.eq('LASSO')].groupby(['cohort','seed']):
    mapped = channels.merge(oo[['sample','truth','fold']], on='sample', validate='many_to_one')
    assert set(mapped['sample']) == set(oo['sample'])
    for fold, heldout in mapped.groupby('fold'):
        training = mapped[mapped.fold.ne(fold)]
        votes = training.groupby('channel').truth.mean().ge(.5)
        prior = oo.loc[oo.fold.ne(fold),'truth'].mean() >= .5
        calls = (heldout.assign(vote=heldout.channel.map(votes).fillna(prior))
                 .groupby('sample').vote.mean().ge(.5).astype(int))
        part = oo[oo.fold.eq(fold)][['cohort','seed','fold','sample','patient','truth']].copy()
        part['pred'] = part['sample'].map(calls)
        channel_predictions.append(part)
channel_oof = pd.concat(channel_predictions, ignore_index=True)
save_benchmark('channel_only_oof_predictions',channel_oof)
channel_summary = []
for (cohort,seed), g in channel_oof.groupby(['cohort','seed']):
    channel_summary.append(dict(cohort=cohort,seed=seed,n=len(g),
      correct=int(g.truth.eq(g.pred).sum()), balanced_accuracy=balanced_accuracy_score(g.truth,g.pred),
      f1=f1_score(g.truth,g.pred)))
save_benchmark('channel_only_metrics',channel_summary)
display(pd.DataFrame(channel_summary))

matches = []
for cohort, g in predictions.groupby('cohort'):
    wide = g.pivot(index=['seed','fold','sample'], columns='arm', values='pred')
    cc = clauses[clauses.cohort.eq(cohort)]
    ss = cc[cc.arm.isin(['Full FOL/ILP','Coefficient'])].pivot(
        index=['seed','fold','rule_id'], columns='arm', values='signature')
    matches.append(dict(cohort=cohort,n=len(wide),
      coefficient_agreement=int(wide['Full FOL/ILP'].eq(wide.Coefficient).sum()),
      threshold_agreement=int(wide['Full FOL/ILP'].eq(wide['Single threshold']).sum()),
      identical_clause_signatures=bool(ss['Full FOL/ILP'].eq(ss.Coefficient).all())))
save_benchmark('rule_agreement',matches)
display(pd.DataFrame(matches))
save_benchmark('attribution_gate',gate_rows)
save_benchmark('inner_tuning',tuning_rows)
archive = shutil.make_archive(BASE_DIR+'/IWMMA_Matched_Audit_Outputs','zip', OUT_DIR)
print(archive)

