# IWMMA 2026 · CPTAC-LUAD reproducibility package

**Auditing SHAP Guidance in Symbolic Rules for Lung Adenocarcinoma Proteomics**  
Surajit Das · Manuscript 20

## Start here

- `data/` contains the four supplied source files. The input SHA-256 hashes are recorded in both run manifests. The manuscript identifies the source as CPTAC-LUAD study PDC000153.
- `matched/` contains the verified scikit-learn 1.8.0 benchmark, a Colab notebook, a local runner and the outputs regenerated from the supplied data. It includes the absolute-coefficient comparator and the TMT-channel control.
- `original/` contains the archived original analysis notebook, intermediate files, out-of-fold predictions, results and figures. Its recorded environment used scikit-learn 1.6.1. The earlier ablation notebook is retained for provenance under `notebook_legacy_benchmark/`.
- `manuscript/` contains the revised LaTeX and all four external images it references. The other diagrams are embedded in the TeX.
- `presentation/` and `submission/` contain the 30-slide deck and point-by-point response.

Use `matched/outputs/` for the manuscript's common-fold comparison. The original classifier and rule evaluations used separate folds. Their scores document the original analysis.

## Rerun the matched benchmark

**Colab.** Open `matched/IWMMA_LUAD_Matched_Audit.ipynb` in a fresh runtime and run all cells. When prompted, upload this ZIP or the original input ZIP. The notebook extracts the four named input files and creates an output ZIP. The analysis cells were run locally with the supplied inputs. The hosted upload and installation steps were not exercised.

**Local Python.** Use Python 3.12 and run from the extracted package root.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r matched/requirements.txt
python matched/run_matched_audit.py --data-dir data --output-dir luad_rerun
```

The runner writes `luad_rerun/FOL_ILP_Benchmark/OUTPUT/` and `luad_rerun/IWMMA_Matched_Audit_Outputs.zip`. Originals in the extracted package remain available for comparison. To inspect a different run location, change `--output-dir`.

**Original evaluations.** The archived notebook targets Google Drive. Point its configuration at a project folder with the four source files under `0_Dataset/` and use the recorded versions as an environment reference. The original historical run and figure generation are supplied as archived artefacts. The original notebook was not rerun as part of this packaging step.

## Read the matched outputs

| Output | Contents |
|---|---|
| matched_metrics.csv, matched_oof_predictions.csv | Pooled metrics and held-out tissue predictions for each benchmark arm |
| paired_patient_bootstrap_delta_f1.csv | Patient-cluster bootstrap intervals, conditional on fitted predictions |
| inner_tuning.csv, attribution_gate.csv | Fold-specific tuning scores, selected C values, attribution cutoff and candidate overlap |
| matched_clauses.csv, matched_rule_complexity.csv | Learned clauses and search-term counts |
| rule_recurrence_signature.csv, rule_recurrence_pattern.csv | Exact clause and rule-pattern recurrence |
| heldout_rule_witnesses.csv | Protein, measured abundance, imputation status and threshold for fired terms |
| rule_agreement.csv | Prediction agreement for the coefficient and single-threshold comparators |
| channel_only_metrics.csv, channel_only_oof_predictions.csv | TMT-channel control trained using the same patient-grouped folds |
| matched_run_manifest.json | Input checksums and audited package versions |

Expected all-patient matched F1 values are 0.9600 for full rules, 0.9910 without SHAP, 0.9909 for L1 logistic regression and 0.9911 for TMT channel alone. The absolute-coefficient arm reproduces the full rule predictions for all 417 held-out tissue records across both analyses. The paired-only analysis is a subset of CPTAC-LUAD. A single threshold reproduces all 204 full-rule predictions in that subset.

The channel-only result limits the interpretation of near-ceiling tissue classification. The released outputs support the audit of what SHAP guidance changed under the reported split design.

## Verify archive contents

From the extracted package root, run `sha256sum -c SHA256SUMS.txt` on a system with GNU coreutils. Compile the manuscript with its `figures/` folder available. Pagination in the proceedings template has not been verified.
